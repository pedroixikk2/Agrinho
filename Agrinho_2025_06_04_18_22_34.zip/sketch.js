// Variáveis globais para os recursos
let food = 100; // Recurso do campo (alimentos)
let goods = 100; // Recurso da cidade (produtos)
let happiness = 100; // Novo recurso: Satisfação da População

// Taxas de consumo e produção
const INITIAL_DECAY_RATE = 0.15; // Taxa de consumo inicial para ambos os recursos (AUMENTADA)
const PRODUCTION_AMOUNT = 15; // Quanto de recurso é adicionado ao produzir
const CONSUMPTION_PER_PRODUCTION = 5; // Quanto do outro recurso é consumido ao produzir
const PRODUCTION_COOLDOWN = 1000; // Tempo de espera para os botões de produção (1 segundo)

// Cores
const COUNTRY_COLOR = '#6B8E23'; // Verde-oliva para o campo
const CITY_COLOR = '#808080'; // Cinza para a cidade
const FOOD_BAR_COLOR = '#4CAF50'; // Verde para a barra de alimentos
const GOODS_BAR_COLOR = '#FFC107'; // Amarelo para a barra de produtos
const HAPPINESS_BAR_COLOR = '#8A2BE2'; // Roxo para a barra de satisfação
const BUTTON_COLOR_COUNTRY = '#28A745'; // Verde mais escuro para o botão do campo
const BUTTON_COLOR_CITY = '#007BFF'; // Azul para o botão da cidade
const TEXT_COLOR = '#FFFFFF'; // Branco para o texto
const GAME_OVER_OVERLAY = 'rgba(0, 0, 0, 0.7)'; // Overlay escuro para Game Over
const SKY_COLOR = '#87CEEB'; // Azul claro para o céu
const CRITICAL_ALERT_COLOR = '#FF0000'; // Vermelho para alertas críticos
const ROAD_COLOR = '#404040'; // Cor da estrada
const CAR_COLOR = '#FF00FF'; // Cor do carro (magenta)
const RIVER_COLOR = '#4682B4'; // Cor do rio (azul aço)
const CROP_COLOR = '#B8860B'; // Cor da plantação (dourado)
const COOLDOWN_OVERLAY_COLOR = 'rgba(0, 0, 0, 0.5)'; // Overlay escuro para botões em cooldown

// Variáveis para feedback visual
let foodProductionEffect = { active: false, x: 0, y: 0, alpha: 255, text: '', startTime: 0 };
let goodsProductionEffect = { active: false, x: 0, y: 0, alpha: 255, text: '', startTime: 0 };
let buttonAnimation = { active: false, button: '', startTime: 0 };

// Estado do jogo
let gameOver = false;
let gameStarted = false; // Para controlar a tela inicial

// Variável para a pontuação
let score = 0;
let lastScoreUpdateTime = 0;
const SCORE_UPDATE_INTERVAL = 100; // Atualiza a pontuação a cada 100ms

// Variáveis para eventos aleatórios
let eventMessage = '';
let eventStartTime = 0;
const EVENT_DISPLAY_DURATION = 3000; // Duração que a mensagem do evento fica na tela (3 segundos)
let nextEventTime = 0; // Próximo momento para um evento ocorrer
const MIN_EVENT_INTERVAL = 8000; // Intervalo mínimo entre eventos (8 segundos - mais frequente)
const MAX_EVENT_INTERVAL = 25000; // Intervalo máximo entre eventos (25 segundos - mais frequente)

// Definição dos eventos possíveis
const events = [
  { text: "Boa colheita! +10 Alimentos!", resource: 'food', amount: 10 },
  { text: "Praga na lavoura! -15 Alimentos!", resource: 'food', amount: -15 },
  { text: "Inovação industrial! +10 Produtos!", resource: 'goods', amount: 10 },
  { text: "Crise de energia! -15 Produtos!", resource: 'goods', amount: -15 },
  { text: "Demanda alta! +5 Alimentos e +5 Produtos!", resource: 'both', amount: 5 },
  { text: "Desastres naturais! -10 Alimentos e -10 Produtos!", resource: 'both', amount: -10 },
  { text: "Festival local! +10 Satisfação!", resource: 'happiness', amount: 10 }, // Novo evento
  { text: "Protestos! -10 Satisfação!", resource: 'happiness', amount: -10 } // Novo evento
];

// Variáveis para dificuldade progressiva
let difficultyMultiplier = 1.0; // Multiplicador inicial da dificuldade
const DIFFICULTY_INCREASE_RATE = 0.00008; // Quanto a dificuldade aumenta por ponto de pontuação (AUMENTADA)

// Variáveis para interdependência de recursos e alertas críticos
const FOOD_CRITICAL_THRESHOLD = 25; // Limite para alerta de alimentos (AUMENTADO)
const GOODS_CRITICAL_THRESHOLD = 25; // Limite para alerta de produtos (AUMENTADO)
const CRITICAL_DECAY_BOOST = 0.07; // Aumento na taxa de consumo quando um recurso está crítico (AUMENTADO)

// Variáveis para o novo medidor de Satisfação
const HAPPINESS_DECAY_RATE = 0.03; // Taxa de diminuição da satisfação (AUMENTADA)
const HAPPINESS_GAIN_THRESHOLD = 65; // Limite acima do qual food e goods geram satisfação (AUMENTADO)
const HAPPINESS_GAIN_AMOUNT = 0.04; // Quanto de satisfação é gerado por frame (AJUSTADO)

// Variáveis para o cooldown dos botões
let lastFoodProductionTime = 0;
let lastGoodsProductionTime = 0;


// Função de configuração do p5.js
function setup() {
  // Cria o canvas que se adapta à largura da janela e tem uma altura fixa
  createCanvas(windowWidth, 400);
  // Define o modo de cor HSB (Hue, Saturation, Brightness)
  colorMode(HSB, 360, 100, 100);
  // Define o alinhamento do texto no centro
  textAlign(CENTER, CENTER);
  // Define o tamanho da fonte
  textSize(16);
  // Define o frame rate para controlar a velocidade do jogo
  frameRate(30);
  lastScoreUpdateTime = millis(); // Inicializa o tempo da última atualização da pontuação
  // Agenda o primeiro evento
  nextEventTime = millis() + random(MIN_EVENT_INTERVAL, MAX_EVENT_INTERVAL);
}

// Função principal de desenho do p5.js, executada continuamente
function draw() {
  // Se o jogo não começou, mostra a tela inicial
  if (!gameStarted) {
    drawStartScreen();
  } else if (!gameOver) {
    // Se o jogo está em andamento e não é Game Over
    background(SKY_COLOR); // Cor de fundo azul claro para o céu

    // Desenha a divisão cidade-campo com elementos visuais
    drawBackgroundDivision();

    // Atualiza os recursos (consumo contínuo)
    updateResources();

    // Atualiza a pontuação
    updateScore();

    // Lida com eventos aleatórios
    handleEvents();

    // Atualiza a dificuldade do jogo
    updateDifficulty();

    // Atualiza a satisfação da população
    updateHappiness();

    // Desenha as barras de recursos
    drawResourceBars();

    // Desenha os botões de produção
    drawButtons();

    // Desenha o texto dos recursos
    drawResourceText();

    // Desenha os efeitos de produção de recursos
    drawProductionEffects();

    // Desenha a pontuação
    drawScore();

    // Verifica a condição de Game Over
    checkGameOver();
  } else {
    // Se é Game Over, mostra a tela de Game Over
    drawGameOverScreen();
  }
}

// Desenha a tela inicial do jogo
function drawStartScreen() {
  background(CITY_COLOR); // Fundo cinza para a tela inicial
  fill(TEXT_COLOR); // Cor do texto branca
  textSize(32);
  text('Equilíbrio: Cidade e Campo', width / 2, height / 2 - 50);
  textSize(18);
  text('Clique para iniciar', width / 2, height / 2 + 20);
  textSize(14);
  text('Produza Alimentos e Produtos para manter o equilíbrio!', width / 2, height / 2 + 60);
  text('Mantenha a Satisfação da População alta!', width / 2, height / 2 + 90);
}

// Desenha a divisão visual entre cidade e campo com elementos imersivos
function drawBackgroundDivision() {
  // Campo (lado esquerdo)
  fill(COUNTRY_COLOR);
  rect(0, height / 2, width / 2, height / 2); // Base verde para o campo

  // Desenha algumas colinas
  fill(hue(COUNTRY_COLOR), saturation(COUNTRY_COLOR) * 0.8, brightness(COUNTRY_COLOR) * 0.9); // Cor um pouco mais escura
  ellipse(width / 4, height / 2 + 50, width / 3, 150);
  ellipse(width / 4 + 80, height / 2 + 30, width / 4, 120);

  // Desenha mais árvores
  fill(100, 50, 30); // Tronco marrom
  rect(width / 4 - 100, height / 2 + 80, 20, 50);
  rect(width / 4 + 50, height / 2 + 100, 20, 50);
  rect(width / 4 - 180, height / 2 + 120, 15, 40); // Nova árvore
  rect(width / 4 + 150, height / 2 + 90, 18, 45); // Nova árvore
  fill(FOOD_BAR_COLOR); // Folhas verdes
  ellipse(width / 4 - 90, height / 2 + 70, 60, 60);
  ellipse(width / 4 + 60, height / 2 + 90, 50, 50);
  ellipse(width / 4 - 170, height / 2 + 110, 45, 45); // Folhas nova árvore
  ellipse(width / 4 + 160, height / 2 + 80, 55, 55); // Folhas nova árvore

  // Desenha plantações
  fill(CROP_COLOR);
  rect(width / 4 - 200, height / 2 + 180, 100, 30);
  rect(width / 4 + 100, height / 2 + 160, 80, 25);

  // Desenha um rio simples
  fill(RIVER_COLOR);
  beginShape();
  vertex(width / 2 - 50, height / 2);
  bezierVertex(width / 2 - 80, height / 2 + 50, width / 2 - 10, height / 2 + 100, width / 2 - 120, height);
  vertex(width / 2 - 150, height);
  bezierVertex(width / 2 - 10, height / 2 + 100, width / 2 - 70, height / 2 + 50, width / 2 - 80, height / 2);
  endShape(CLOSE);


  // Cidade (lado direito)
  fill(CITY_COLOR);
  rect(width / 2, height / 2, width / 2, height / 2); // Base cinza para a cidade

  // Desenha mais prédios
  fill(hue(CITY_COLOR), saturation(CITY_COLOR) * 0.8, brightness(CITY_COLOR) * 0.9); // Cor um pouco mais escura
  rect(width / 2 + 50, height / 2 + 30, 80, 120);
  rect(width / 2 + 150, height / 2 + 50, 60, 100);
  rect(width / 2 + 230, height / 2 + 10, 70, 140);
  rect(width / 2 + 320, height / 2 + 70, 50, 80); // Novo prédio
  rect(width / 2 + 10, height / 2 + 80, 40, 70); // Novo prédio

  // Desenha janelas nos prédios
  fill(200, 10, 90); // Amarelo claro para as janelas
  // Prédio 1
  rect(width / 2 + 60, height / 2 + 40, 15, 15);
  rect(width / 2 + 80, height / 2 + 40, 15, 15);
  rect(width / 2 + 60, height / 2 + 65, 15, 15);
  rect(width / 2 + 80, height / 2 + 65, 15, 15);
  // Prédio 2
  rect(width / 2 + 160, height / 2 + 60, 10, 10);
  rect(width / 2 + 180, height / 2 + 60, 10, 10);
  // Prédio 3
  rect(width / 2 + 240, height / 2 + 20, 12, 12);
  rect(width / 2 + 260, height / 2 + 20, 12, 12);
  rect(width / 2 + 240, height / 2 + 40, 12, 12);
  rect(width / 2 + 260, height / 2 + 40, 12, 12);
  // Novo prédio 1
  rect(width / 2 + 330, height / 2 + 80, 10, 10);
  rect(width / 2 + 350, height / 2 + 80, 10, 10);
  // Novo prédio 2
  rect(width / 2 + 20, height / 2 + 90, 8, 8);
  rect(width / 2 + 30, height / 2 + 90, 8, 8);

  // Desenha uma estrada
  fill(ROAD_COLOR);
  rect(width / 2, height / 2 + 150, width / 2, 30);
  // Linhas da estrada
  fill(TEXT_COLOR);
  rect(width / 2 + 20, height / 2 + 164, 20, 2);
  rect(width / 2 + 60, height / 2 + 164, 20, 2);
  rect(width / 2 + 100, height / 2 + 164, 20, 2);
  rect(width / 2 + 140, height / 2 + 164, 20, 2);

  // Desenha um carro simples
  fill(CAR_COLOR);
  rect(width / 2 + 200, height / 2 + 155, 30, 20, 5); // Corpo do carro
  fill(0); // Rodas
  ellipse(width / 2 + 205, height / 2 + 175, 8, 8);
  ellipse(width / 2 + 225, height / 2 + 175, 8, 8);
}

// Atualiza os valores dos recursos com base nas taxas de consumo e dificuldade
function updateResources() {
  let currentFoodDecay = INITIAL_DECAY_RATE * difficultyMultiplier;
  let currentGoodsDecay = INITIAL_DECAY_RATE * difficultyMultiplier;

  // Aumenta o consumo do outro recurso se um estiver crítico
  if (food < FOOD_CRITICAL_THRESHOLD) {
    currentGoodsDecay += CRITICAL_DECAY_BOOST; // Produtos diminuem mais rápido se alimentos estiverem baixos
  }
  if (goods < GOODS_CRITICAL_THRESHOLD) {
    currentFoodDecay += CRITICAL_DECAY_BOOST; // Alimentos diminuem mais rápido se produtos estiverem baixos
  }

  food -= currentFoodDecay;
  goods -= currentGoodsDecay;

  // Garante que os recursos não fiquem abaixo de zero
  food = max(0, food);
  goods = max(0, goods);
}

// Atualiza a pontuação
function updateScore() {
  if (millis() - lastScoreUpdateTime > SCORE_UPDATE_INTERVAL) {
    score++; // Aumenta a pontuação
    lastScoreUpdateTime = millis();
  }
}

// Atualiza a satisfação da população
function updateHappiness() {
  happiness -= HAPPINESS_DECAY_RATE; // Satisfação diminui com o tempo

  // Se ambos os recursos estiverem acima de um certo limite, a satisfação aumenta
  if (food > HAPPINESS_GAIN_THRESHOLD && goods > HAPPINESS_GAIN_THRESHOLD) {
    happiness += HAPPINESS_GAIN_AMOUNT;
  }

  // Se algum recurso estiver crítico, a satisfação diminui mais rápido
  if (food < FOOD_CRITICAL_THRESHOLD || goods < GOODS_CRITICAL_THRESHOLD) {
    happiness -= CRITICAL_DECAY_BOOST * 0.5; // Diminui a satisfação mais rápido
  }

  happiness = constrain(happiness, 0, 100); // Limita a satisfação entre 0 e 100
}

// Desenha a pontuação na tela
function drawScore() {
  fill(TEXT_COLOR);
  textSize(20);
  text(`Pontuação: ${score}`, width / 2, 25); // Posição da pontuação no topo central
}

// Desenha as barras de progresso dos recursos
function drawResourceBars() {
  const barWidth = width * 0.4; // Largura da barra (40% da largura do canvas)
  const barHeight = 30; // Altura da barra
  const barYOffset = 50; // Posição Y inicial das barras

  // Barra de Alimentos (Campo)
  // Adiciona alerta visual se o alimento estiver crítico
  if (food < FOOD_CRITICAL_THRESHOLD) {
    stroke(CRITICAL_ALERT_COLOR);
    strokeWeight(4);
  } else {
    noStroke();
  }
  fill(FOOD_BAR_COLOR);
  // Mapeia o valor do alimento para a largura da barra (máximo de 100)
  rect(width / 2 - barWidth / 2, barYOffset, map(food, 0, 100, 0, barWidth), barHeight, 5); // 5 para bordas arredondadas
  noFill();
  stroke(TEXT_COLOR);
  strokeWeight(2);
  rect(width / 2 - barWidth / 2, barYOffset, barWidth, barHeight, 5); // Borda da barra
  noStroke();

  // Barra de Produtos (Cidade)
  // Adiciona alerta visual se o produto estiver crítico
  if (goods < GOODS_CRITICAL_THRESHOLD) {
    stroke(CRITICAL_ALERT_COLOR);
    strokeWeight(4);
  } else {
    noStroke();
  }
  fill(GOODS_BAR_COLOR);
  rect(width / 2 - barWidth / 2, barYOffset + barHeight + 20, map(goods, 0, 100, 0, barWidth), barHeight, 5);
  noFill();
  stroke(TEXT_COLOR);
  strokeWeight(2);
  rect(width / 2 - barWidth / 2, barYOffset + barHeight + 20, barWidth, barHeight, 5);
  noStroke();

  // Barra de Satisfação (Nova)
  if (happiness < 25) { // Alerta visual para satisfação baixa
    stroke(CRITICAL_ALERT_COLOR);
    strokeWeight(4);
  } else {
    noStroke();
  }
  fill(HAPPINESS_BAR_COLOR);
  rect(width / 2 - barWidth / 2, barYOffset + (barHeight + 20) * 2, map(happiness, 0, 100, 0, barWidth), barHeight, 5);
  noFill();
  stroke(TEXT_COLOR);
  strokeWeight(2);
  rect(width / 2 - barWidth / 2, barYOffset + (barHeight + 20) * 2, barWidth, barHeight, 5);
  noStroke();
}

// Desenha o texto dos valores dos recursos
function drawResourceText() {
  const barHeight = 30;
  const barYOffset = 50;

  fill(TEXT_COLOR);
  textSize(18);
  text(`Alimentos: ${floor(food)}`, width / 2, barYOffset + barHeight / 2);
  text(`Produtos: ${floor(goods)}`, width / 2, barYOffset + barHeight + 20 + barHeight / 2);
  text(`Satisfação: ${floor(happiness)}`, width / 2, barYOffset + (barHeight + 20) * 2 + barHeight / 2);
}

// Desenha os botões de produção
function drawButtons() {
  const buttonWidth = 180;
  const buttonHeight = 50;
  const buttonYOffset = height - 100; // Posição Y dos botões (próximo à parte inferior)
  const buttonSpacing = 40; // Espaçamento entre os botões

  let currentScaleCountry = 1;
  let currentScaleCity = 1;

  // Animação do botão
  if (buttonAnimation.active) {
    const elapsed = millis() - buttonAnimation.startTime;
    const duration = 150; // Duração da animação em ms
    if (elapsed < duration) {
      const progress = elapsed / duration;
      const scaleFactor = 1 - (0.1 * sin(progress * PI)); // Escala de 1 para 0.9 e volta
      if (buttonAnimation.button === 'country') {
        currentScaleCountry = scaleFactor;
      } else if (buttonAnimation.button === 'city') {
        currentScaleCity = scaleFactor;
      }
    } else {
      buttonAnimation.active = false;
    }
  }

  push(); // Salva o estado atual da transformação
  translate(width / 2 - buttonWidth - (buttonSpacing / 2) + buttonWidth / 2, buttonYOffset + buttonHeight / 2);
  scale(currentScaleCountry);
  translate(-(width / 2 - buttonWidth - (buttonSpacing / 2) + buttonWidth / 2), -(buttonYOffset + buttonHeight / 2));
  // Botão "Produzir Alimentos" (Campo)
  let countryButtonColor = BUTTON_COLOR_COUNTRY;
  if (millis() - lastFoodProductionTime < PRODUCTION_COOLDOWN) {
    countryButtonColor = color(red(BUTTON_COLOR_COUNTRY), green(BUTTON_COLOR_COUNTRY), blue(BUTTON_COLOR_COUNTRY), 100); // Mais transparente
  }
  fill(countryButtonColor);
  rect(width / 2 - buttonWidth - (buttonSpacing / 2), buttonYOffset, buttonWidth, buttonHeight, 8); // 8 para bordas arredondadas
  fill(TEXT_COLOR);
  textSize(16);
  text('Produzir Alimentos', width / 2 - buttonWidth - (buttonSpacing / 2) + buttonWidth / 2, buttonYOffset + buttonHeight / 2);
  pop(); // Restaura o estado da transformação

  push(); // Salva o estado atual da transformação
  translate(width / 2 + (buttonSpacing / 2) + buttonWidth / 2, buttonYOffset + buttonHeight / 2);
  scale(currentScaleCity);
  translate(-(width / 2 + (buttonSpacing / 2) + buttonWidth / 2), -(buttonYOffset + buttonHeight / 2));
  // Botão "Produzir Produtos" (Cidade)
  let cityButtonColor = BUTTON_COLOR_CITY;
  if (millis() - lastGoodsProductionTime < PRODUCTION_COOLDOWN) {
    cityButtonColor = color(red(BUTTON_COLOR_CITY), green(BUTTON_COLOR_CITY), blue(BUTTON_COLOR_CITY), 100); // Mais transparente
  }
  fill(cityButtonColor);
  rect(width / 2 + (buttonSpacing / 2), buttonYOffset, buttonWidth, buttonHeight, 8);
  fill(TEXT_COLOR);
  text('Produzir Produtos', width / 2 + (buttonSpacing / 2) + buttonWidth / 2, buttonYOffset + buttonHeight / 2);
  pop(); // Restaura o estado da transformação
}

// Lida com eventos aleatórios que afetam os recursos
function handleEvents() {
  // Se o tempo para o próximo evento chegou e o jogo não acabou
  if (millis() > nextEventTime && !gameOver) {
    let chosenEvent = random(events); // Escolhe um evento aleatoriamente
    eventMessage = chosenEvent.text; // Define a mensagem do evento
    eventStartTime = millis(); // Registra o início da exibição da mensagem

    // Aplica o efeito do evento nos recursos
    if (chosenEvent.resource === 'food') {
      food += chosenEvent.amount;
    } else if (chosenEvent.resource === 'goods') {
      goods += chosenEvent.amount;
    } else if (chosenEvent.resource === 'both') {
      food += chosenEvent.amount;
      goods += chosenEvent.amount;
    } else if (chosenEvent.resource === 'happiness') { // Novo recurso de evento
      happiness += chosenEvent.amount;
    }


    // Garante que os recursos não ultrapassem o máximo (100) ou fiquem abaixo de zero (0)
    food = constrain(food, 0, 100);
    goods = constrain(goods, 0, 100);
    happiness = constrain(happiness, 0, 100); // Garante que a satisfação também seja limitada

    // Agenda o próximo evento
    nextEventTime = millis() + random(MIN_EVENT_INTERVAL, MAX_EVENT_INTERVAL);
  }

  // Exibe a mensagem do evento se estiver ativa e dentro do tempo de exibição
  if (eventMessage !== '' && millis() - eventStartTime < EVENT_DISPLAY_DURATION) {
    fill(TEXT_COLOR);
    textSize(22);
    text(eventMessage, width / 2, height / 2 + 100); // Posição da mensagem ajustada para evitar sobreposição
  } else {
    eventMessage = ''; // Limpa a mensagem após a duração
  }
}

// Atualiza a dificuldade do jogo com base na pontuação
function updateDifficulty() {
  // Aumenta o multiplicador de dificuldade linearmente com a pontuação
  difficultyMultiplier = 1.0 + (score * DIFFICULTY_INCREASE_RATE);
  // O INITIAL_DECAY_RATE é aplicado em updateResources usando este multiplicador
}

// Desenha os efeitos de produção de recursos (texto flutuante)
function drawProductionEffects() {
  const fadeDuration = 1000; // Duração do efeito em ms

  // Efeito de produção de Alimentos
  if (foodProductionEffect.active) {
    const elapsed = millis() - foodProductionEffect.startTime;
    if (elapsed < fadeDuration) {
      foodProductionEffect.y -= 0.5; // Move para cima
      foodProductionEffect.alpha = map(elapsed, 0, fadeDuration, 255, 0); // Desaparece
      fill(255, foodProductionEffect.alpha); // Cor branca com transparência
      textSize(20);
      text(foodProductionEffect.text, foodProductionEffect.x, foodProductionEffect.y);
    } else {
      foodProductionEffect.active = false;
    }
  }

  // Efeito de produção de Produtos
  if (goodsProductionEffect.active) {
    const elapsed = millis() - goodsProductionEffect.startTime;
    if (elapsed < fadeDuration) {
      goodsProductionEffect.y -= 0.5; // Move para cima
      goodsProductionEffect.alpha = map(elapsed, 0, fadeDuration, 255, 0); // Desaparece
      fill(255, goodsProductionEffect.alpha); // Cor branca com transparência
      textSize(20);
      text(goodsProductionEffect.text, goodsProductionEffect.x, goodsProductionEffect.y);
    } else {
      goodsProductionEffect.active = false;
    }
  }
}


// Verifica se o jogo acabou
function checkGameOver() {
  if (food <= 0 || goods <= 0 || happiness <= 0) { // Adiciona condição para satisfação zero
    gameOver = true;
  }
}

// Desenha a tela de Game Over
function drawGameOverScreen() {
  background(GAME_OVER_OVERLAY); // Fundo escuro semi-transparente
  fill(TEXT_COLOR);
  textSize(48);
  text('GAME OVER', width / 2, height / 2 - 50);
  textSize(24);
  text('Recursos esgotados!', width / 2, height / 2);
  textSize(18);
  text(`Sua pontuação: ${score}`, width / 2, height / 2 + 20); // Exibe a pontuação final
  textSize(18);
  text('Clique para reiniciar', width / 2, height / 2 + 50);
}

// Lida com cliques do mouse
function mousePressed() {
  // Se o jogo não começou, inicia
  if (!gameStarted) {
    gameStarted = true;
    lastScoreUpdateTime = millis(); // Inicia o contador de pontuação ao começar o jogo
    nextEventTime = millis() + random(MIN_EVENT_INTERVAL, MAX_EVENT_INTERVAL); // Agenda o primeiro evento
    return; // Sai da função para evitar cliques duplos
  }

  // Se o jogo acabou, reinicia ao clicar
  if (gameOver) {
    resetGame();
    return; // Sai da função
  }

  // Verifica se o clique foi nos botões de produção
  const buttonWidth = 180;
  const buttonHeight = 50;
  const buttonYOffset = height - 100;
  const buttonSpacing = 40;

  // Botão "Produzir Alimentos"
  if (mouseX > (width / 2 - buttonWidth - (buttonSpacing / 2)) &&
      mouseX < (width / 2 - (buttonSpacing / 2)) &&
      mouseY > buttonYOffset &&
      mouseY < (buttonYOffset + buttonHeight)) {
    produceFood();
    buttonAnimation = { active: true, button: 'country', startTime: millis() };
  }

  // Botão "Produzir Produtos"
  if (mouseX > (width / 2 + (buttonSpacing / 2)) &&
      mouseX < (width / 2 + (buttonSpacing / 2) + buttonWidth) &&
      mouseY > buttonYOffset &&
      mouseY < (buttonYOffset + buttonHeight)) {
    produceGoods();
    buttonAnimation = { active: true, button: 'city', startTime: millis() };
  }
}

// Função para produzir alimentos (aumenta food, consome goods)
function produceFood() {
  // Só produz se tiver produtos suficientes E o cooldown tiver passado
  if (millis() - lastFoodProductionTime > PRODUCTION_COOLDOWN && goods >= CONSUMPTION_PER_PRODUCTION) {
    food += PRODUCTION_AMOUNT;
    goods -= CONSUMPTION_PER_PRODUCTION;
    food = min(100, food); // Limita o recurso a um máximo
    lastFoodProductionTime = millis(); // Atualiza o tempo da última produção

    // Ativa o efeito de produção de alimentos
    foodProductionEffect = {
      active: true,
      x: width / 2,
      y: 50 + 30 / 2, // Posição da barra de alimentos
      alpha: 255,
      text: `+${PRODUCTION_AMOUNT} Alimentos!`,
      startTime: millis()
    };
  } else {
    console.log("Não há produtos suficientes ou botão em cooldown para produzir alimentos!");
  }
}

// Função para produzir produtos (aumenta goods, consome food)
function produceGoods() {
  // Só produz se tiver alimentos suficientes E o cooldown tiver passado
  if (millis() - lastGoodsProductionTime > PRODUCTION_COOLDOWN && food >= CONSUMPTION_PER_PRODUCTION) {
    goods += PRODUCTION_AMOUNT;
    food -= CONSUMPTION_PER_PRODUCTION;
    goods = min(100, goods); // Limita o recurso a um máximo
    lastGoodsProductionTime = millis(); // Atualiza o tempo da última produção

    // Ativa o efeito de produção de produtos
    goodsProductionEffect = {
      active: true,
      x: width / 2,
      y: 50 + 30 + 20 + 30 / 2, // Posição da barra de produtos
      alpha: 255,
      text: `+${PRODUCTION_AMOUNT} Produtos!`,
      startTime: millis()
    };
  } else {
    console.log("Não há alimentos suficientes ou botão em cooldown para produzir produtos!");
  }
}

// Reinicia o jogo
function resetGame() {
  food = 100;
  goods = 100;
  happiness = 100; // Reseta a satisfação
  gameOver = false;
  gameStarted = false; // Volta para a tela inicial
  foodProductionEffect.active = false; // Reseta efeitos
  goodsProductionEffect.active = false;
  buttonAnimation.active = false;
  score = 0; // Reseta a pontuação
  lastScoreUpdateTime = 0; // Reseta o tempo da pontuação
  eventMessage = ''; // Reseta mensagem de evento
  eventStartTime = 0; // Reseta tempo de início do evento
  nextEventTime = millis() + random(MIN_EVENT_INTERVAL, MAX_EVENT_INTERVAL); // Agenda o primeiro evento para o novo jogo
  difficultyMultiplier = 1.0; // Reseta o multiplicador de dificuldade
  lastFoodProductionTime = 0; // Reseta o cooldown dos botões
  lastGoodsProductionTime = 0;
}

// Função para lidar com o redimensionamento da janela
function windowResized() {
  resizeCanvas(windowWidth, 400);
}
